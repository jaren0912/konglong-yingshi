恐龙影视 Android TV 项目原型
==============================

项目内容：
- Android TV 横屏首页，品牌名“恐龙影视”
- 预设直播源：http://bit.ly/jaren919
- 预设点播源：http://bit.ly/jaren22
- M3U/M3U8 频道列表解析及 Media3 播放器
- CMS 点播源连通性/格式检查占位页面
- 电视遥控器基础焦点操作
- 可在设置页面修改源地址

重要说明：
1. 这是可继续开发的 Android Studio 项目原型，不是已经编译、验证的 APK。
2. 当前环境没有 Android SDK/Gradle 构建工具，因此不能在这里直接编译 APK。
3. 直播短链接必须实际返回 M3U 文本才可显示频道。
4. 点播短链接的 CMS 类型和 API 数据结构尚未确认，因此点播分类、海报、详情、剧集播放还需要按真实接口继续开发。
5. 商业发行前请确认内容播放/分发授权，并测试目标 EVPAD 型号的 Android 版本、CPU 架构及遥控器兼容性。
6. 为安全起见，不建议商业版本长期使用 HTTP；优先使用 HTTPS，并加入授权服务、隐私说明、异常处理和更新机制。

如何构建：
- 在电脑安装 Android Studio（建议较新稳定版本）。
- 打开此文件夹作为项目。
- 等待 Gradle Sync 完成并安装所需 Android SDK（compileSdk 35）。
- 连接测试设备，先 Run 测试。
- 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
- 调试 APK 通常在 app/build/outputs/apk/debug/app-debug.apk。
